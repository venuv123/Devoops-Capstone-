export username="pmbrull"

export PORT=5000
export LOCAL_PORT=5000

# Docker image parameters
export path=k8-flask-api
export version=0.1

# Create dockerpath
export dockerpath=$username/$path;